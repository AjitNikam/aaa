package com.cg.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.cg.bean.LoginBean;
import com.cg.model.Login;
import com.cg.service.LoginService;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@RequestMapping(value = "/save1", method = RequestMethod.POST)
	public ModelAndView saveUser(@ModelAttribute("command") LoginBean loginBean, 
			BindingResult result) {
		Login login = prepareModel1(loginBean);
		loginService.addUser(login);
		return new ModelAndView("redirect:/index.html");
	}
	
	@RequestMapping(value="/Users", method = RequestMethod.GET)
	public ModelAndView listUsers() {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("Users",  prepareListofBean1(loginService.listUsers()));
		return new ModelAndView("usersList", model);
	}
	
	@RequestMapping(value = "/add1", method = RequestMethod.GET)
	public ModelAndView addUser(@ModelAttribute("command")  LoginBean loginBean, 
			BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("Login",  prepareListofBean1(loginService.listUsers()));
		return new ModelAndView("addUser", model);
	}
	
	@RequestMapping(value = "/LoginPage", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}
	
	private Login prepareModel1(LoginBean loginBean) {
		Login login = new Login();
		login.setLoginName(loginBean.getLoginName());
		login.setLoginEmail(loginBean.getLoginEmail());
		login.setLoginPassword(loginBean.getLoginPassword());
		loginBean.setLoginId(null);
		return login;
	}
	
	@SuppressWarnings("rawtypes")
	private List prepareListofBean1(List<Login> listUsers) {
		List<LoginBean> beans = null;
		if(listUsers != null && !listUsers.isEmpty()){
			beans = new ArrayList<LoginBean>();
			LoginBean bean = null;
			for(Login login : listUsers){
				bean = new LoginBean();
				bean.setLoginName(login.getLoginName());
				bean.setLoginId(login.getLoginId());
				bean.setLoginEmail(login.getLoginEmail());
				bean.setLoginPassword(login.getLoginPassword());
				beans.add(bean);
			}
		}
		return beans;
	}
	}

	
	


