package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.cg.dao.LoginDao;
import com.cg.model.Login;


@Service("loginService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao;

	@Override
	public Login getUser(int loginId) {
		return loginDao.getUser(loginId);
	}

	@Override
	public void addUser(Login login) {
		loginDao.addUser(login);

	}

	@Override
	public List<Login> listUsers() {
		return loginDao.listUsers();
	}

	@Override
	public boolean validateUser(Login login) {

		return loginDao.validateUser(login);
	}



}
