package com.cg.dao;

import java.util.List;


import com.cg.model.Login;

public interface LoginDao {
	
	public void addUser(Login login);

	public List<Login> listUsers();
	
	public Login getUser(int loginId);
	
	public boolean validateUser(Login login);

}
