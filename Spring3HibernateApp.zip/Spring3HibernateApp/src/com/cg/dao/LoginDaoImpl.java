package com.cg.dao;


import java.util.List;

import com.cg.model.Login;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository("loginDao")
public class LoginDaoImpl implements LoginDao {
	
	@Autowired
	private SessionFactory sessionFactory1;

	@Override
	public Login getUser(int loginId) {
		return (Login) sessionFactory1.getCurrentSession().get(Login.class, loginId);
	}

	@Override
	public void addUser(Login login) {
		sessionFactory1.getCurrentSession().save(login);
		
	}

	@SuppressWarnings("unchecked")
	public List<Login> listUsers() {
		return (List<Login>) sessionFactory1.getCurrentSession().createCriteria(Login.class).list();
	}

	@Override
	public boolean validateUser(Login login) {
		Criteria criteria = sessionFactory1.getCurrentSession().createCriteria(Login.class)
			    .add(Restrictions.eq("loginemail", login.getLoginEmail()));
		if(!criteria.list().isEmpty()){
			return true;
		}		 
		return false;
	}

}
