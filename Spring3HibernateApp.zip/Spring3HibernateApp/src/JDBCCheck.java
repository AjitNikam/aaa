
import java.sql.*;
public class JDBCCheck {
	static final String JDBC_Driver="org.h2.Driver";
	static final String DB_URL="jdbc:h2:tcp://localhost/~/test";
	
	static final String USER="sa";
	static final String PASS="";
	
	public static void main(String[] args) {
		Connection conn=null;
		Statement stmt=null;
		
		try{
			Class.forName(JDBC_Driver);
			
			System.out.println("Connecting to Database...");
			conn=DriverManager.getConnection(DB_URL,USER,PASS);
			
			System.out.println("Creating Statement...");
			stmt=conn.createStatement();
			String sql;
			sql="SELECT empid,first,last,age FROM Employees";
			ResultSet rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				int empid=rs.getInt("empid");
				int age=rs.getInt("age");
				String first=rs.getString("first");
				String last=rs.getString("last");
				
				System.out.println("ID:"+empid);
				System.out.println(",AGE:"+age);
				System.out.println(",FIRST:"+first);
				System.out.println(",LAST:"+last);
					
					
				
			}
			rs.close();
			stmt.close();
			conn.close();
			}catch(SQLException se){
				se.printStackTrace();
							
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				try{
					if(stmt!=null)
						stmt.close();
					}catch(SQLException se2){
						
					}try{
						if(conn!=null)
							conn.close();
						}catch(SQLException se){
							se.printStackTrace();
						}
	
			}
		System.out.println("Bye");
	}
	
}


			
					
					
		
	
	


